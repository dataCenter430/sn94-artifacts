"""Unified quantization-aware (QAT) byte-level model for SN94 binary AND ternary
frontier tasks.

Key differences from modeling_packed.py:
  * Quantization-Aware Training: during training each weight is fake-quantized in
    the forward with a straight-through estimator (STE), so the network LEARNS
    weights that survive binary/ternary quantization. Post-training quant (the old
    path) made more training *worse*; QAT makes more training monotonically better.
  * One model for both modes (config.quant_mode in {"binary","ternary"}).
  * fp16 "rescue": config.emb_fp16 keeps the token embedding / tied lm-head in
    fp16 (the most sensitive weights) within the size budget.

Storage at inference: quantized tensors -> int8 codes ({-1,+1} or {-1,0,+1}) +
fp16 scale (deflate-compresses to ~1.2 b/p binary / ~1.5 b/p ternary); rescued
tensors -> fp16. param_count (validator counts model.parameters()) stays full.
Loads via AutoModelForCausalLM(trust_remote_code=True), validator's exact path.
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import PretrainedConfig, PreTrainedModel
from transformers.modeling_outputs import CausalLMOutput

TERNARY_THRESH = 0.7  # threshold * mean|w| below which a ternary weight is 0


def _ln(x, w, b, eps):
    x32 = x.float()
    mean = x32.mean(-1, keepdim=True)
    var = x32.var(-1, unbiased=False, keepdim=True)
    return (x32 - mean) / torch.sqrt(var + eps) * w.float() + b.float()


def fake_quant(w, mode):
    """STE fake-quant used during training."""
    scale = w.detach().abs().mean().clamp_min(1e-12)
    if mode == "ternary":
        thr = TERNARY_THRESH * scale
        q = torch.where(w.detach().abs() > thr, torch.sign(w) * scale, torch.zeros_like(w))
    else:
        q = torch.where(w >= 0, scale, -scale)
    return w + (q - w).detach()


def quant_codes(w, mode):
    """Pack-time: int8 codes + fp16 scale (matches fake_quant exactly)."""
    scale = w.abs().mean().clamp_min(1e-12)
    if mode == "ternary":
        thr = TERNARY_THRESH * scale
        code = torch.zeros_like(w, dtype=torch.int8)
        code[w > thr] = 1
        code[w < -thr] = -1
    else:
        code = torch.where(w >= 0, 1, -1).to(torch.int8)
    return code, scale.reshape(1).to(torch.float16)


class QParam(nn.Module):
    """Holds one 2D weight: dense fp32 (train) / int8 codes+scale (packed quant) /
    fp16 (packed rescue)."""

    def __init__(self, rows, cols, *, quantized, mode, packed):
        super().__init__()
        self.rows, self.cols, self.quantized, self.mode, self.packed = rows, cols, quantized, mode, packed
        if not packed:
            self.weight = nn.Parameter(torch.empty(rows, cols))
            nn.init.normal_(self.weight, std=0.02)
        elif quantized:
            self.weight_code = nn.Parameter(torch.zeros(rows, cols, dtype=torch.int8), requires_grad=False)
            self.weight_scale = nn.Parameter(torch.zeros(1, dtype=torch.float16), requires_grad=False)
        else:
            self.weight = nn.Parameter(torch.zeros(rows, cols, dtype=torch.float16), requires_grad=False)

    def eff(self):
        if not self.packed:
            return fake_quant(self.weight, self.mode) if self.quantized else self.weight
        if self.quantized:
            return self.weight_code.to(torch.float32) * self.weight_scale.to(torch.float32)
        return self.weight

    @torch.no_grad()
    def pack_(self):
        if self.quantized:
            code, scale = quant_codes(self.weight, self.mode)
            del self._parameters["weight"]
            self.weight_code = nn.Parameter(code, requires_grad=False)
            self.weight_scale = nn.Parameter(scale, requires_grad=False)
        else:
            self.weight = nn.Parameter(self.weight.detach().to(torch.float16), requires_grad=False)
        self.packed = True


class PackedQuantConfig(PretrainedConfig):
    model_type = "packed_quant_gpt"

    def __init__(self, vocab_size=260, n_positions=512, n_embd=256, n_layer=6, n_head=8,
                 layer_norm_epsilon=1e-5, quant_mode="ternary", emb_fp16=False, packed=False, **kwargs):
        self.vocab_size = vocab_size
        self.n_positions = n_positions
        self.n_embd = n_embd
        self.n_layer = n_layer
        self.n_head = n_head
        self.layer_norm_epsilon = layer_norm_epsilon
        self.quant_mode = quant_mode
        self.emb_fp16 = emb_fp16
        self.packed = packed
        super().__init__(**kwargs)


class Block(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.n_head, self.eps, m, p = cfg.n_head, cfg.layer_norm_epsilon, cfg.quant_mode, cfg.packed
        self.ln1 = nn.LayerNorm(cfg.n_embd, eps=cfg.layer_norm_epsilon)
        self.ln2 = nn.LayerNorm(cfg.n_embd, eps=cfg.layer_norm_epsilon)
        self.qkv = QParam(3 * cfg.n_embd, cfg.n_embd, quantized=True, mode=m, packed=p)
        self.proj = QParam(cfg.n_embd, cfg.n_embd, quantized=True, mode=m, packed=p)
        self.fc = QParam(4 * cfg.n_embd, cfg.n_embd, quantized=True, mode=m, packed=p)
        self.fc_proj = QParam(cfg.n_embd, 4 * cfg.n_embd, quantized=True, mode=m, packed=p)

    def forward(self, x):
        x = x.float()
        B, T, C = x.shape
        h = _ln(x, self.ln1.weight, self.ln1.bias, self.eps)
        q, k, v = F.linear(h, self.qkv.eff().float()).split(C, dim=2)
        hd = C // self.n_head
        q = q.view(B, T, self.n_head, hd).transpose(1, 2)
        k = k.view(B, T, self.n_head, hd).transpose(1, 2)
        v = v.view(B, T, self.n_head, hd).transpose(1, 2)
        att = (q @ k.transpose(-2, -1)) / math.sqrt(hd)
        mask = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), 1)
        att = att.masked_fill(mask, float("-inf")).softmax(-1)
        y = (att @ v).transpose(1, 2).contiguous().view(B, T, C)
        x = x + F.linear(y, self.proj.eff().float())
        h2 = _ln(x, self.ln2.weight, self.ln2.bias, self.eps)
        x = x + F.linear(F.gelu(F.linear(h2, self.fc.eff().float())), self.fc_proj.eff().float())
        return x


class PackedQuantLMHeadModel(PreTrainedModel):
    config_class = PackedQuantConfig

    def __init__(self, config: PackedQuantConfig):
        super().__init__(config)
        m, p = config.quant_mode, config.packed
        q_emb = not config.emb_fp16
        self.tok = QParam(config.vocab_size, config.n_embd, quantized=q_emb, mode=m, packed=p)
        self.pos = QParam(config.n_positions, config.n_embd, quantized=q_emb, mode=m, packed=p)
        self.blocks = nn.ModuleList([Block(config) for _ in range(config.n_layer)])
        self.ln_f = nn.LayerNorm(config.n_embd, eps=config.layer_norm_epsilon)
        self.eps = config.layer_norm_epsilon
        self.post_init()

    def forward(self, input_ids=None, attention_mask=None, labels=None,
                past_key_values=None, use_cache=None, **kwargs):
        B, T = input_ids.shape
        tok_w = self.tok.eff().float()  # compute in fp32 throughout (robust to fp16/int8 param mix)
        x = F.embedding(input_ids, tok_w) + self.pos.eff().float()[None, :T, :]
        for blk in self.blocks:
            x = blk(x)
        x = _ln(x, self.ln_f.weight, self.ln_f.bias, self.eps)
        logits = F.linear(x, tok_w)  # tied lm head, fp32
        loss = None
        if labels is not None:
            loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)),
                                   labels[:, 1:].reshape(-1))
        return CausalLMOutput(loss=loss, logits=logits)

    @torch.no_grad()
    def pack(self):
        for mod in self.modules():
            if isinstance(mod, QParam):
                mod.pack_()
        self.config.packed = True
        return self


PackedQuantConfig.register_for_auto_class()
PackedQuantLMHeadModel.register_for_auto_class("AutoModelForCausalLM")
