"""Self-contained byte-level GPT for SN94 BitSota autoresearch artifact submission.

Own implementation. Loaded by the validator via:
  AutoModelForCausalLM.from_pretrained(dir, trust_remote_code=True,
                                       local_files_only=True, torch_dtype=fp16)

Scoring contract (competition_packs/qwen3_27b_shared/shared.py):
  * Byte-level tokenisation: token_id = byte + 1 (ids in [1,256]); vocab >= 257.
  * parameter_count = sum(p.numel() for p in model.parameters()); this counts the
    DENSE `weight` Parameters of each quant linear and sets the per-parameter
    artifact-size budget (file_bits <= ~1.3125 * params binary, ~1.84 ternary).
  * On disk we store ONLY packed buffers (1-bit signs or base-3 trits + per-row
    fp16 scales) for the bulk linears, plus fp16 sensitive tensors (token
    embedding, position, lm_head, norms, biases). The dense `weight` Parameters
    are counted but never saved (load as zeros) and never used in compute.
  * forward returns rank-3 logits, no usable cache -> validator full-prefix path.
"""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers import PreTrainedModel, PretrainedConfig
from transformers.modeling_outputs import CausalLMOutputWithPast


class ByteGPTConfig(PretrainedConfig):
    model_type = "bytegpt"

    def __init__(
        self,
        vocab_size: int = 257,
        n_embd: int = 256,
        n_layer: int = 8,
        n_head: int = 8,
        block_size: int = 512,
        quant_mode: str = "ternary",  # "binary" | "ternary"
        mlp_ratio: int = 4,
        tie_head: bool = True,
        **kwargs,
    ):
        self.vocab_size = vocab_size
        self.n_embd = n_embd
        self.n_layer = n_layer
        self.n_head = n_head
        self.block_size = block_size
        self.quant_mode = quant_mode
        self.mlp_ratio = mlp_ratio
        self.tie_head = tie_head
        super().__init__(**kwargs)


# --------------------------------------------------------------------------- #
# Bit packing (torch-only)
# --------------------------------------------------------------------------- #
_BIT = torch.arange(8, dtype=torch.uint8)
_POW3 = torch.tensor([1, 3, 9, 27, 81], dtype=torch.long)  # 5 trits / byte


def pack_signs(sign_pm1: torch.Tensor) -> torch.Tensor:
    bits = (sign_pm1.reshape(-1) > 0).to(torch.uint8)
    pad = (-bits.numel()) % 8
    if pad:
        bits = torch.cat([bits, torch.zeros(pad, dtype=torch.uint8)])
    bits = bits.reshape(-1, 8)
    return (bits * (1 << _BIT)).sum(dim=1).to(torch.uint8)


def unpack_signs(packed: torch.Tensor, n: int) -> torch.Tensor:
    bits = ((packed.reshape(-1, 1) >> _BIT.to(packed.device)) & 1).reshape(-1)[:n]
    return bits.to(torch.float32) * 2.0 - 1.0


def pack_ternary(code012: torch.Tensor) -> torch.Tensor:
    c = code012.reshape(-1).to(torch.long)
    pad = (-c.numel()) % 5
    if pad:
        c = torch.cat([c, torch.zeros(pad, dtype=torch.long)])
    c = c.reshape(-1, 5)
    return (c * _POW3.to(c.device)).sum(dim=1).to(torch.uint8)


def unpack_ternary(packed: torch.Tensor, n: int) -> torch.Tensor:
    v = packed.reshape(-1, 1).to(torch.long)
    trits = (v // _POW3.to(packed.device)) % 3
    return trits.reshape(-1)[:n].to(torch.float32) - 1.0  # {-1,0,+1}


# --------------------------------------------------------------------------- #
# Quantised linear: dense `weight` counted (zeros, unused); packed buffers used.
# --------------------------------------------------------------------------- #
class QuantLinear(nn.Module):
    def __init__(self, in_f: int, out_f: int, bias: bool = True, quant_mode: str = "ternary"):
        super().__init__()
        self.in_f, self.out_f, self.quant_mode = int(in_f), int(out_f), quant_mode
        n = self.in_f * self.out_f
        if quant_mode == "ternary":
            self.register_buffer("qcode", torch.zeros((n + 4) // 5, dtype=torch.uint8), persistent=True)
        else:
            self.register_buffer("qsign", torch.zeros((n + 7) // 8, dtype=torch.uint8), persistent=True)
        self.register_buffer("qscale", torch.ones(self.out_f, dtype=torch.float16), persistent=True)
        # Counted-but-unused dense weight: sets validator parameter_count / budget.
        self.weight = nn.Parameter(torch.zeros(self.out_f, self.in_f, dtype=torch.float16), requires_grad=False)
        self.bias = nn.Parameter(torch.zeros(self.out_f, dtype=torch.float16)) if bias else None

    def dequant_weight(self) -> torch.Tensor:
        n = self.in_f * self.out_f
        base = unpack_ternary(self.qcode, n) if self.quant_mode == "ternary" else unpack_signs(self.qsign, n)
        return base.reshape(self.out_f, self.in_f).to(self.qscale.dtype) * self.qscale.reshape(-1, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        w = self.dequant_weight().to(x.dtype)
        b = self.bias.to(x.dtype) if self.bias is not None else None
        return F.linear(x, w, b)

    @torch.no_grad()
    def load_dense(self, dense: torch.Tensor) -> None:
        dense = dense.detach().to(torch.float32)
        if self.quant_mode == "ternary":
            thr = 0.7 * dense.abs().mean(dim=1, keepdim=True)
            code = torch.zeros_like(dense)
            code[dense > thr] = 1.0
            code[dense < -thr] = -1.0
            mask = code != 0
            scale = (dense.abs() * mask).sum(dim=1) / mask.sum(dim=1).clamp(min=1)
            self.qcode.copy_(pack_ternary((code + 1.0).to(torch.uint8)))
        else:
            scale = dense.abs().mean(dim=1)
            self.qsign.copy_(pack_signs(torch.where(dense >= 0, 1.0, -1.0)))
        self.qscale.copy_(scale.to(torch.float16))


class Block(nn.Module):
    def __init__(self, cfg: ByteGPTConfig):
        super().__init__()
        self.n_head, self.n_embd = cfg.n_head, cfg.n_embd
        self.ln1 = nn.LayerNorm(cfg.n_embd)
        self.ln2 = nn.LayerNorm(cfg.n_embd)
        self.qkv = QuantLinear(cfg.n_embd, 3 * cfg.n_embd, bias=True, quant_mode=cfg.quant_mode)
        self.proj = QuantLinear(cfg.n_embd, cfg.n_embd, bias=True, quant_mode=cfg.quant_mode)
        h = cfg.mlp_ratio * cfg.n_embd
        self.fc = QuantLinear(cfg.n_embd, h, bias=True, quant_mode=cfg.quant_mode)
        self.fc_proj = QuantLinear(h, cfg.n_embd, bias=True, quant_mode=cfg.quant_mode)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        h = self.ln1(x)
        q, k, v = self.qkv(h).split(self.n_embd, dim=2)
        hd = C // self.n_head
        q = q.view(B, T, self.n_head, hd).transpose(1, 2)
        k = k.view(B, T, self.n_head, hd).transpose(1, 2)
        v = v.view(B, T, self.n_head, hd).transpose(1, 2)
        att = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        x = x + self.proj(att.transpose(1, 2).contiguous().view(B, T, C))
        x = x + self.fc_proj(F.gelu(self.fc(self.ln2(x))))
        return x


class ByteGPTForCausalLM(PreTrainedModel):
    config_class = ByteGPTConfig
    _no_split_modules = ["Block"]

    def __init__(self, config: ByteGPTConfig):
        super().__init__(config)
        # fp16 "rescue" sensitive tensors (high precision, small param share)
        self.tok = nn.Embedding(config.vocab_size, config.n_embd)
        self.pos = nn.Parameter(torch.zeros(config.block_size, config.n_embd, dtype=torch.float16))
        self.blocks = nn.ModuleList([Block(config) for _ in range(config.n_layer)])
        self.ln_f = nn.LayerNorm(config.n_embd)
        if config.tie_head:
            self.head = None  # tie to tok embedding
        else:
            self.head = nn.Linear(config.n_embd, config.vocab_size, bias=False)
        self.post_init()

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        kwargs["low_cpu_mem_usage"] = False
        kwargs.pop("device_map", None)
        kwargs.pop("tp_plan", None)
        model = super().from_pretrained(*args, **kwargs)
        for _n, p in model.named_parameters():
            if getattr(p, "is_meta", False):
                p.data = torch.zeros(p.shape, dtype=p.dtype)
        return model

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        past_key_values=None,
        **kwargs,
    ) -> CausalLMOutputWithPast:
        if input_ids.dim() == 1:
            input_ids = input_ids.unsqueeze(0)
        B, T = input_ids.shape
        T = min(T, self.config.block_size)
        input_ids = input_ids[:, -T:].long().clamp_(0, self.config.vocab_size - 1)
        x = self.tok(input_ids).to(torch.float16) + self.pos[:T].to(torch.float16).unsqueeze(0)
        for blk in self.blocks:
            x = blk(x)
        x = self.ln_f(x)
        if self.head is None:
            logits = F.linear(x, self.tok.weight.to(x.dtype)).float()
        else:
            logits = self.head(x).float()
        loss = None
        if labels is not None:
            labels = labels[:, -T:]
            loss = F.cross_entropy(
                logits[:, :-1, :].reshape(-1, logits.size(-1)),
                labels[:, 1:].reshape(-1).long(),
                ignore_index=-100,
            )
        return CausalLMOutputWithPast(loss=loss, logits=logits, past_key_values=None)
