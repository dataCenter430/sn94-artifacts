"""Self-contained Qwen-vocab mini-GPT for SN94 BitSota autoresearch artifact submission.

Own implementation. Loaded by the validator via:
  AutoModelForCausalLM.from_pretrained(dir, trust_remote_code=True,
                                       local_files_only=True, torch_dtype=fp16)

Scoring contract (competition_packs/qwen3_27b_shared/shared.py, run_direct_model_benchmark):
  * Tokeniser = Qwen/Qwen3.6-27B (BPE), the REFERENCE model (validator sets
    AUTORESEARCH_EVAL_TOKENIZER_ID to it).  Heldout text is tokenised with it, so the
    model MUST emit rank-3 logits whose last dim (vocab_size) is >= max token id+1.
    Qwen3.6-27B tokenizer len ~248077 -> use vocab_size = 248320 (its config value).
    A smaller vocab triggers: "target token id outside logits vocabulary" (benchmark
    aborts, validator reports "result file not found ... last_run.json").
  * parameter_count = sum(p.numel() for p in model.parameters()).  This counts the
    DENSE `weight` Parameters of each QuantLinear / QuantEmbedding (created as zeros,
    never saved, never used in compute) and sets the per-parameter artifact-size
    budget:  file_bits <= per_param_budget * param_count
             binary  per_param_budget = 1.3125   (0.9*1.0 + 0.1*4.125)
             ternary per_param_budget = 2.2125   (0.9*2.0 + 0.1*4.125)
  * On disk we store ONLY packed buffers (1-bit signs OR base-3 trits + per-row fp16
    scales) for the bulk tensors (token embedding + all linears), plus small fp16
    "rescue" tensors (pos, norms, biases).  Package with ZIP_DEFLATED so the unsaved /
    zero dense weights cost ~nothing.
  * Unlike the byte model (vocab 257, tiny fp16 embedding), the Qwen embedding is the
    DOMINANT block (248320 x n_embd), so it is quantised here via QuantEmbedding and
    tied to the LM head.
  * forward returns rank-3 logits, no usable cache -> validator full-prefix path.
"""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers import PreTrainedModel, PretrainedConfig
from transformers.modeling_outputs import CausalLMOutputWithPast


class QwenMiniConfig(PretrainedConfig):
    model_type = "qwenmini"

    def __init__(
        self,
        vocab_size: int = 248320,
        n_embd: int = 512,
        n_layer: int = 12,
        n_head: int = 8,
        block_size: int = 512,
        quant_mode: str = "binary",  # "binary" | "ternary"
        mlp_ratio: int = 4,
        tie_head: bool = True,
        **kwargs,
    ):
        self.vocab_size = vocab_size
        self.n_embd = n_embd
        self.n_layer = n_layer
        self.n_head = n_head
        self.block_size = block_size
        self.quant_mode = quant_mode
        self.mlp_ratio = mlp_ratio
        self.tie_head = tie_head
        super().__init__(**kwargs)


# --------------------------------------------------------------------------- #
# Bit packing (torch-only)
# --------------------------------------------------------------------------- #
_BIT = torch.arange(8, dtype=torch.uint8)
_POW3 = torch.tensor([1, 3, 9, 27, 81], dtype=torch.long)  # 5 trits / byte
_SH2 = torch.tensor([0, 2, 4, 6], dtype=torch.uint8)        # 4 x 2-bit codes / byte (quad)


def pack_signs(sign_pm1: torch.Tensor) -> torch.Tensor:
    bits = (sign_pm1.reshape(-1) > 0).to(torch.uint8)
    pad = (-bits.numel()) % 8
    if pad:
        bits = torch.cat([bits, torch.zeros(pad, dtype=torch.uint8)])
    bits = bits.reshape(-1, 8)
    return (bits * (1 << _BIT)).sum(dim=1).to(torch.uint8)


def unpack_signs(packed: torch.Tensor, n: int) -> torch.Tensor:
    bits = ((packed.reshape(-1, 1) >> _BIT.to(packed.device)) & 1).reshape(-1)[:n]
    return bits.to(torch.float32) * 2.0 - 1.0


def pack_ternary(code012: torch.Tensor) -> torch.Tensor:
    c = code012.reshape(-1).to(torch.long)
    pad = (-c.numel()) % 5
    if pad:
        c = torch.cat([c, torch.zeros(pad, dtype=torch.long)])
    c = c.reshape(-1, 5)
    return (c * _POW3.to(c.device)).sum(dim=1).to(torch.uint8)


def unpack_ternary(packed: torch.Tensor, n: int) -> torch.Tensor:
    v = packed.reshape(-1, 1).to(torch.long)
    trits = (v // _POW3.to(packed.device)) % 3
    return trits.reshape(-1)[:n].to(torch.float32) - 1.0  # {-1,0,+1}


def pack_quad(code0123: torch.Tensor) -> torch.Tensor:
    # 4 levels (codes 0..3 -> values {-1.5,-0.5,0.5,1.5}); 4 codes / byte (2 bits each)
    c = code0123.reshape(-1).to(torch.uint8)
    pad = (-c.numel()) % 4
    if pad:
        c = torch.cat([c, torch.zeros(pad, dtype=torch.uint8)])
    c = c.reshape(-1, 4)
    return (c << _SH2).sum(dim=1).to(torch.uint8)


def unpack_quad(packed: torch.Tensor, n: int) -> torch.Tensor:
    codes = ((packed.reshape(-1, 1) >> _SH2.to(packed.device)) & 3).reshape(-1)[:n]
    return codes.to(torch.float32) - 1.5  # {-1.5,-0.5,0.5,1.5}


@torch.no_grad()
def _quantize_dense(dense: torch.Tensor, quant_mode: str):
    """Return (packed_buffer, scale_per_row) matching the (un)pack helpers above."""
    dense = dense.detach().to(torch.float32)
    out_f = dense.shape[0]
    if quant_mode == "quad":
        # 4-level symmetric uniform quant; per-row scale s so max(|w|) -> +-1.5 s.
        s = (dense.abs().amax(dim=1) / 1.5).clamp(min=1e-8)
        t = dense / s.reshape(-1, 1)
        code = (t + 1.5).round().clamp(0, 3).to(torch.uint8)
        packed = pack_quad(code)
        scale = s
    elif quant_mode == "ternary":
        thr = 0.7 * dense.abs().mean(dim=1, keepdim=True)
        code = torch.zeros_like(dense)
        code[dense > thr] = 1.0
        code[dense < -thr] = -1.0
        mask = code != 0
        scale = (dense.abs() * mask).sum(dim=1) / mask.sum(dim=1).clamp(min=1)
        packed = pack_ternary((code + 1.0).to(torch.uint8))
    else:
        scale = dense.abs().mean(dim=1)
        packed = pack_signs(torch.where(dense >= 0, 1.0, -1.0))
    return packed, scale.to(torch.float16)


# --------------------------------------------------------------------------- #
# Quantised linear: dense `weight` counted (zeros, unused); packed buffers used.
# --------------------------------------------------------------------------- #
class QuantLinear(nn.Module):
    def __init__(self, in_f: int, out_f: int, bias: bool = True, quant_mode: str = "binary"):
        super().__init__()
        self.in_f, self.out_f, self.quant_mode = int(in_f), int(out_f), quant_mode
        n = self.in_f * self.out_f
        if quant_mode == "ternary":
            self.register_buffer("qcode", torch.zeros((n + 4) // 5, dtype=torch.uint8), persistent=True)
        elif quant_mode == "quad":
            self.register_buffer("qquad", torch.zeros((n + 3) // 4, dtype=torch.uint8), persistent=True)
        else:
            self.register_buffer("qsign", torch.zeros((n + 7) // 8, dtype=torch.uint8), persistent=True)
        self.register_buffer("qscale", torch.ones(self.out_f, dtype=torch.float16), persistent=True)
        # Counted-but-unused dense weight: sets validator parameter_count / budget.
        self.weight = nn.Parameter(torch.zeros(self.out_f, self.in_f, dtype=torch.float16), requires_grad=False)
        self.bias = nn.Parameter(torch.zeros(self.out_f, dtype=torch.float16)) if bias else None

    def dequant_weight(self) -> torch.Tensor:
        n = self.in_f * self.out_f
        if self.quant_mode == "ternary":
            base = unpack_ternary(self.qcode, n)
        elif self.quant_mode == "quad":
            base = unpack_quad(self.qquad, n)
        else:
            base = unpack_signs(self.qsign, n)
        return base.reshape(self.out_f, self.in_f).to(self.qscale.dtype) * self.qscale.reshape(-1, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        w = self.dequant_weight().to(x.dtype)
        b = self.bias.to(x.dtype) if self.bias is not None else None
        return F.linear(x, w, b)

    @torch.no_grad()
    def load_dense(self, dense: torch.Tensor) -> None:
        packed, scale = _quantize_dense(dense, self.quant_mode)
        buf = self.qcode if self.quant_mode == "ternary" else (self.qquad if self.quant_mode == "quad" else self.qsign)
        buf.copy_(packed)
        self.qscale.copy_(scale)


# --------------------------------------------------------------------------- #
# Quantised tied embedding / head: the dominant block for a Qwen-vocab model.
# Stores packed (vocab x n_embd) signs/trits + per-row (per-token) fp16 scale.
# --------------------------------------------------------------------------- #
class QuantEmbedding(nn.Module):
    def __init__(self, vocab: int, dim: int, quant_mode: str = "binary"):
        super().__init__()
        self.vocab, self.dim, self.quant_mode = int(vocab), int(dim), quant_mode
        n = self.vocab * self.dim
        if quant_mode == "ternary":
            self.register_buffer("qcode", torch.zeros((n + 4) // 5, dtype=torch.uint8), persistent=True)
        elif quant_mode == "quad":
            self.register_buffer("qquad", torch.zeros((n + 3) // 4, dtype=torch.uint8), persistent=True)
        else:
            self.register_buffer("qsign", torch.zeros((n + 7) // 8, dtype=torch.uint8), persistent=True)
        self.register_buffer("qscale", torch.ones(self.vocab, dtype=torch.float16), persistent=True)
        # Counted-but-unused dense weight: dominates parameter_count -> budget.
        self.weight = nn.Parameter(torch.zeros(self.vocab, self.dim, dtype=torch.float16), requires_grad=False)

    def table(self) -> torch.Tensor:
        n = self.vocab * self.dim
        if self.quant_mode == "ternary":
            base = unpack_ternary(self.qcode, n)
        elif self.quant_mode == "quad":
            base = unpack_quad(self.qquad, n)
        else:
            base = unpack_signs(self.qsign, n)
        return base.reshape(self.vocab, self.dim).to(self.qscale.dtype) * self.qscale.reshape(-1, 1)

    def embed(self, input_ids: torch.Tensor) -> torch.Tensor:
        return F.embedding(input_ids, self.table())

    def project(self, x: torch.Tensor) -> torch.Tensor:  # tied LM head
        return F.linear(x, self.table().to(x.dtype))

    @torch.no_grad()
    def load_dense(self, dense: torch.Tensor) -> None:
        packed, scale = _quantize_dense(dense, self.quant_mode)
        buf = self.qcode if self.quant_mode == "ternary" else (self.qquad if self.quant_mode == "quad" else self.qsign)
        buf.copy_(packed)
        self.qscale.copy_(scale)


class Block(nn.Module):
    def __init__(self, cfg: QwenMiniConfig):
        super().__init__()
        self.n_head, self.n_embd = cfg.n_head, cfg.n_embd
        self.ln1 = nn.LayerNorm(cfg.n_embd)
        self.ln2 = nn.LayerNorm(cfg.n_embd)
        self.qkv = QuantLinear(cfg.n_embd, 3 * cfg.n_embd, bias=True, quant_mode=cfg.quant_mode)
        self.proj = QuantLinear(cfg.n_embd, cfg.n_embd, bias=True, quant_mode=cfg.quant_mode)
        h = cfg.mlp_ratio * cfg.n_embd
        self.fc = QuantLinear(cfg.n_embd, h, bias=True, quant_mode=cfg.quant_mode)
        self.fc_proj = QuantLinear(h, cfg.n_embd, bias=True, quant_mode=cfg.quant_mode)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        h = self.ln1(x)
        q, k, v = self.qkv(h).split(self.n_embd, dim=2)
        hd = C // self.n_head
        q = q.view(B, T, self.n_head, hd).transpose(1, 2)
        k = k.view(B, T, self.n_head, hd).transpose(1, 2)
        v = v.view(B, T, self.n_head, hd).transpose(1, 2)
        att = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        x = x + self.proj(att.transpose(1, 2).contiguous().view(B, T, C))
        x = x + self.fc_proj(F.gelu(self.fc(self.ln2(x))))
        return x


class QwenMiniForCausalLM(PreTrainedModel):
    config_class = QwenMiniConfig
    _no_split_modules = ["Block"]

    def __init__(self, config: QwenMiniConfig):
        super().__init__(config)
        self.tok = QuantEmbedding(config.vocab_size, config.n_embd, quant_mode=config.quant_mode)
        self.pos = nn.Parameter(torch.zeros(config.block_size, config.n_embd, dtype=torch.float16))
        self.blocks = nn.ModuleList([Block(config) for _ in range(config.n_layer)])
        self.ln_f = nn.LayerNorm(config.n_embd)
        self.head = None if config.tie_head else QuantLinear(
            config.n_embd, config.vocab_size, bias=False, quant_mode=config.quant_mode
        )
        self.post_init()

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        kwargs["low_cpu_mem_usage"] = False
        kwargs.pop("device_map", None)
        kwargs.pop("tp_plan", None)
        model = super().from_pretrained(*args, **kwargs)
        for _n, p in model.named_parameters():
            if getattr(p, "is_meta", False):
                p.data = torch.zeros(p.shape, dtype=p.dtype)
        return model

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        past_key_values=None,
        **kwargs,
    ) -> CausalLMOutputWithPast:
        if input_ids.dim() == 1:
            input_ids = input_ids.unsqueeze(0)
        B, T = input_ids.shape
        T = min(T, self.config.block_size)
        input_ids = input_ids[:, -T:].long().clamp_(0, self.config.vocab_size - 1)
        # Reconstruct the (vocab x dim) table ONCE per forward and reuse it for both
        # the input lookup and the tied head -> halves dequant work / peak memory on GPU.
        tbl = self.tok.table() if self.head is None else None
        if tbl is not None:
            x = F.embedding(input_ids, tbl).to(torch.float16)
        else:
            x = self.tok.embed(input_ids).to(torch.float16)
        x = x + self.pos[:T].to(torch.float16).unsqueeze(0)
        for blk in self.blocks:
            x = blk(x)
        x = self.ln_f(x)
        # Return fp16 logits (validator casts to float for CE) -> halves logits peak memory.
        logits = F.linear(x, tbl.to(x.dtype)) if tbl is not None else self.head(x)
        loss = None
        if labels is not None:
            labels = labels[:, -T:]
            loss = F.cross_entropy(
                logits[:, :-1, :].reshape(-1, logits.size(-1)).float(),
                labels[:, 1:].reshape(-1).long(),
                ignore_index=-100,
            )
        return CausalLMOutputWithPast(loss=loss, logits=logits, past_key_values=None)
